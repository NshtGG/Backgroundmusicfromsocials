# Background Music from Socials

Paste a link from Instagram, YouTube, TikTok or Facebook. Get the name of the
background music, with the full song playing on the page.

No accounts. No downloads. Black and white, mobile first, 50 languages.

---

## Why there are two pieces

The site runs on Cloudflare Workers, which cannot spawn processes — so it cannot run `yt-dlp`
or `ffmpeg`. Those are what actually open a reel and pull the audio out of it. So the system
splits in two:

| Piece | Runs on | Job |
|---|---|---|
| `/` (this Astro app) | Cloudflare Pages/Workers | UI, routing, i18n, calls the other two |
| `/extractor` | Railway, Fly.io, Render, or any VPS | opens the link, returns a 12-second mp3 sample |
| ACRCloud | their servers | fingerprints the sample, returns the track |

Requests flow: browser → `/api/identify` → extractor → ACRCloud → back.

---

## Run it locally

```bash
npm install
npm run dev
```

With no environment variables set, the site runs in **demo mode** — every part of the UI works
(theme, language, validation, states) and the result is a placeholder. That is intentional, so
you can work on the front end without keys.

## Wire up real recognition

1. **ACRCloud.** Create an account at console.acrcloud.com, make an *Audio & Video Recognition*
   project, and copy the host, access key and access secret. The free tier covers a few thousand
   lookups a month, which is plenty to launch.
2. **Deploy the extractor.**
   ```bash
   cd extractor
   docker build -t bmfs-extractor .
   docker run -p 8080:8080 -e EXTRACTOR_TOKEN=some-long-random-string bmfs-extractor
   ```
   Push that image to Railway or Fly. Note its public URL.
3. **Set the variables** (copy `.env.example`):
   - locally → put them in `.dev.vars`
   - in production → Cloudflare dashboard → your project → Settings → Environment variables

## Deploy the site

```bash
npm run build
npx wrangler pages deploy dist
```

Then point `backgroundmusicfromsocials.com` at the project in the Cloudflare dashboard.

---

## How the pieces are laid out

```
src/
  pages/
    index.astro           home — hero, finder, tool index
    [platform].astro      one page per platform, generated from lib/platforms.ts
    privacy.astro
    api/identify.ts       the only server endpoint
    i18n/[lang].json.ts   one JSON dictionary per language, fetched on demand
  components/Finder.astro the paste field, meter, result, error
  lib/
    platforms.ts          add a platform here and its page appears
    finder-client.ts      browser-side logic for the finder
  i18n/
    languages.ts          the 50 languages and their text direction
    strings.ts            16 UI strings × 50 languages
  styles/global.css       the whole design system, about 200 lines
extractor/                the Node service
```

### Adding a platform

Add an entry to `src/lib/platforms.ts`. The tool page, the footer link, the home grid, and the
URL validation all read from that one array. Then add its hostnames to `ALLOWED` in
`extractor/server.js`.

### Adding or fixing a translation

Edit `src/i18n/strings.ts`. Every key is used in at least one place; if a key is missing for a
language, the English string is used instead of breaking.

---

## Design notes

- Two colours, `--ink` and `--page`, that swap on theme change. Every other value in the
  stylesheet is an opacity of `--ink`. That is what makes the buttons invert for free.
- Montserrat, self-hosted via @fontsource so nothing is fetched from Google at runtime.
  Only weights 400/500/600/700 are bundled, subset by the browser as needed.
- The logo is a headphone drawn in `currentColor`, so it flips with the theme without a second
  asset. Same for the favicon and the mountain.
- The mountain is one SVG pinned to the bottom of the viewport at low opacity. Pale grey on
  white, dim grey on black — no image swap, no second file.
- The language picker is a button and a list, not a `<select>`. Native option lists are painted
  by the operating system and stay white on a black page whatever the CSS says.
- Everything is sized for a thumb first. The paste field is full width, the buttons clear the
  44px touch target, and the input is 16px so iOS Safari does not zoom on focus.
- Pasting a valid link fires the search automatically. On a phone the whole interaction is one
  long-press and one tap.

## Deliberate limits

- **No downloads.** The site names the track and plays it from YouTube. Hosting audio files is
  what gets sites like this taken offline.
- **The player needs a video ID**, which ACRCloud supplies for most commercial tracks. When it
  does not, the result falls back to a YouTube search button. Filling that gap would need the
  YouTube Data API, whose free quota is about 100 searches a day — not worth the dependency.
- **Pitch-shifted and sped-up audio often fails to match.** That is how acoustic fingerprinting
  works, and it is the single most common reason a lookup comes back empty.
