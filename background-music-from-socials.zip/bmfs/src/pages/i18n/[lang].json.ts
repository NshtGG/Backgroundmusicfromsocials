import type { APIRoute } from 'astro';
import { strings } from '../../i18n/strings';
import { languages, langCodes } from '../../i18n/languages';

export function getStaticPaths() {
  return langCodes.map((lang) => ({ params: { lang } }));
}

export const GET: APIRoute = ({ params }) => {
  const lang = params.lang as keyof typeof languages;
  const dict = strings[lang];
  if (!dict) return new Response('Not found', { status: 404 });

  return new Response(JSON.stringify({ ...dict, __dir: languages[lang].dir }), {
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'public, max-age=31536000, immutable',
    },
  });
};
