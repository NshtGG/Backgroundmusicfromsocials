import type { APIRoute } from 'astro';
import { platformForUrl } from '../../lib/platforms';

export const prerender = false;

type Env = {
  EXTRACTOR_URL?: string;
  EXTRACTOR_TOKEN?: string;
  ACR_HOST?: string;
  ACR_ACCESS_KEY?: string;
  ACR_ACCESS_SECRET?: string;
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });

/** ACRCloud signs requests with HMAC-SHA1 over a fixed field order. */
async function sign(secret: string, message: string) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-1' },
    false,
    ['sign'],
  );
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(mac)));
}

function base64ToBytes(b64: string) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function demoResult(url: string) {
  return {
    ok: true,
    demo: true,
    track: {
      title: 'Demo mode — no recognition keys set',
      artist: 'Add ACR_ACCESS_KEY and ACR_ACCESS_SECRET to identify real audio',
      album: '',
      year: '',
      label: '',
      youtubeId: null,
    },
    source: platformForUrl(url)?.name ?? null,
  };
}

export const POST: APIRoute = async ({ request, locals }) => {
  const env = ((locals as any)?.runtime?.env ?? {}) as Env;

  let url = '';
  try {
    ({ url } = await request.json());
  } catch {
    return json({ ok: false, message: 'Send a JSON body with a url field.' }, 400);
  }

  const platform = platformForUrl(String(url ?? ''));
  if (!platform) {
    return json({ ok: false, message: 'That link is not supported.' }, 400);
  }

  const { EXTRACTOR_URL, EXTRACTOR_TOKEN, ACR_ACCESS_KEY, ACR_ACCESS_SECRET } = env;
  const ACR_HOST = env.ACR_HOST ?? 'identify-eu-west-1.acrcloud.com';

  if (!EXTRACTOR_URL || !ACR_ACCESS_KEY || !ACR_ACCESS_SECRET) {
    return json(demoResult(url));
  }

  // 1. Pull a short audio sample out of the clip.
  let sample: { sample: string };
  try {
    const res = await fetch(`${EXTRACTOR_URL.replace(/\/$/, '')}/extract`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(EXTRACTOR_TOKEN ? { authorization: `Bearer ${EXTRACTOR_TOKEN}` } : {}),
      },
      body: JSON.stringify({ url, seconds: 12 }),
    });
    if (!res.ok) {
      const text = await res.text();
      return json(
        { ok: false, message: 'We could not open that clip. It may be private or removed.', detail: text.slice(0, 200) },
        502,
      );
    }
    sample = await res.json();
  } catch {
    return json({ ok: false, message: 'The audio service is not responding. Try again shortly.' }, 502);
  }

  // 2. Fingerprint it.
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const bytes = base64ToBytes(sample.sample);
  const signature = await sign(
    ACR_ACCESS_SECRET,
    ['POST', '/v1/identify', ACR_ACCESS_KEY, 'audio', '1', timestamp].join('\n'),
  );

  const form = new FormData();
  form.append('sample', new Blob([bytes]), 'sample.mp3');
  form.append('sample_bytes', String(bytes.length));
  form.append('access_key', ACR_ACCESS_KEY);
  form.append('data_type', 'audio');
  form.append('signature_version', '1');
  form.append('signature', signature);
  form.append('timestamp', timestamp);

  let acr: any;
  try {
    const res = await fetch(`https://${ACR_HOST}/v1/identify`, { method: 'POST', body: form });
    acr = await res.json();
  } catch {
    return json({ ok: false, message: 'Recognition is unavailable right now. Try again shortly.' }, 502);
  }

  if (acr?.status?.code !== 0) {
    return json(
      { ok: false, message: 'No match. Try a clip where the music is clearer.' },
      404,
    );
  }

  const music = acr.metadata?.music?.[0];
  if (!music) {
    return json({ ok: false, message: 'No match. Try a clip where the music is clearer.' }, 404);
  }

  const ytId = music.external_metadata?.youtube?.vid ?? null;

  return json({
    ok: true,
    track: {
      title: music.title ?? 'Unknown title',
      artist: (music.artists ?? []).map((a: any) => a.name).join(', ') || 'Unknown artist',
      album: music.album?.name ?? '',
      year: music.release_date ? String(music.release_date).slice(0, 4) : '',
      label: music.label ?? '',
      youtubeId: ytId,
    },
    source: platform.name,
  });
};
