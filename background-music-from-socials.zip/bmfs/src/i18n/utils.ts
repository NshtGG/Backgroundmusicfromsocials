import { strings, type StringKey } from './strings';
import { defaultLang, type Lang } from './languages';

export function t(key: StringKey, lang: Lang = defaultLang, vars?: Record<string, string>) {
  const raw = strings[lang]?.[key] ?? strings[defaultLang][key];
  if (!vars) return raw;
  return Object.entries(vars).reduce((s, [k, v]) => s.replaceAll(`{${k}}`, v), raw);
}
