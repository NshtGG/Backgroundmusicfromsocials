export type Platform = {
  slug: string;
  name: string;
  /** Hostnames this tool accepts. */
  hosts: string[];
  /** One line of guidance shown under the input. */
  hint: string;
};

export const platforms: Platform[] = [
  {
    slug: 'instagram',
    name: 'Instagram',
    hosts: ['instagram.com', 'instagr.am'],
    hint: 'Reels, posts and stories. Open the reel, tap Share, then Copy link.',
  },
  {
    slug: 'youtube',
    name: 'YouTube',
    hosts: ['youtube.com', 'youtu.be'],
    hint: 'Full videos and Shorts. Paste the address straight from the bar.',
  },
  {
    slug: 'tiktok',
    name: 'TikTok',
    hosts: ['tiktok.com'],
    hint: 'Tap Share, then Copy link. Short vm.tiktok.com links work too.',
  },
  {
    slug: 'facebook',
    name: 'Facebook',
    hosts: ['facebook.com', 'fb.watch'],
    hint: 'Reels and video posts. Use the link from the post menu.',
  },
];

export function platformForUrl(raw: string): Platform | null {
  try {
    const host = new URL(raw.trim()).hostname.toLowerCase().replace(/^www\./, '');
    return (
      platforms.find((p) => p.hosts.some((h) => host === h || host.endsWith('.' + h))) ?? null
    );
  } catch {
    return null;
  }
}
