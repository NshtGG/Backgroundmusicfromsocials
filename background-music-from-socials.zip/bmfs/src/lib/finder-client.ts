import { platformForUrl, platforms } from './platforms';

type Role =
  | 'input' | 'submit' | 'hint' | 'loading' | 'result'
  | 'title' | 'artist' | 'meta' | 'listen' | 'player' | 'player-wrap' | 'error';

const pick = <T extends HTMLElement>(root: HTMLElement, role: Role) =>
  root.querySelector(`[data-role="${role}"]`) as T;

/** Reads a translated string out of the DOM so errors follow the language picker. */
function say(key: 'errNoMatch' | 'errBadLink' | 'errServer', fallback: string) {
  const cached = (window as any).__bmfsDict?.[key];
  return cached ?? fallback;
}

export function init(root: HTMLElement) {
  const input = pick<HTMLInputElement>(root, 'input');
  const submit = pick<HTMLButtonElement>(root, 'submit');
  const loading = pick(root, 'loading');
  const result = pick(root, 'result');
  const error = pick(root, 'error');
  const scoped = root.dataset.platform || null;

  const show = (el: HTMLElement | null) => el && (el.hidden = false);
  const hide = (el: HTMLElement | null) => el && (el.hidden = true);

  function fail(message: string) {
    hide(loading);
    hide(result);
    error.textContent = message;
    show(error);
    submit.disabled = false;
  }

  async function run() {
    const raw = input.value.trim();
    hide(error);
    hide(result);

    if (!raw) {
      input.focus();
      return;
    }

    const detected = platformForUrl(raw);
    if (!detected) {
      fail(say('errBadLink', 'That link is not supported.'));
      return;
    }
    if (scoped && detected.slug !== scoped) {
      const other = platforms.find((p) => p.slug === detected.slug)!;
      fail(`That is a ${other.name} link. Use the ${other.name} tool at /${other.slug}.`);
      return;
    }

    submit.disabled = true;
    show(loading);

    try {
      const res = await fetch('/api/identify', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ url: raw }),
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        fail(data.message || say('errNoMatch', 'No match. Try a clip where the music is clearer.'));
        return;
      }

      pick(root, 'title').textContent = data.track.title;
      pick(root, 'artist').textContent = data.track.artist;

      const bits = [data.track.album, data.track.year, data.track.label].filter(Boolean);
      pick(root, 'meta').textContent = bits.join(' · ');

      const search = `https://www.youtube.com/results?search_query=${encodeURIComponent(
        `${data.track.artist} ${data.track.title}`,
      )}`;

      const wrap = pick(root, 'player-wrap');
      const player = pick<HTMLIFrameElement>(root, 'player');
      const listen = pick<HTMLAnchorElement>(root, 'listen');

      if (data.track.youtubeId) {
        // youtube-nocookie keeps the tracking cookie off until the user presses play.
        player.src = `https://www.youtube-nocookie.com/embed/${data.track.youtubeId}?rel=0&playsinline=1`;
        wrap.hidden = false;
        listen.href = `https://www.youtube.com/watch?v=${data.track.youtubeId}`;
      } else {
        player.removeAttribute('src');
        wrap.hidden = true;
        listen.href = search;
      }

      hide(loading);
      show(result);
      (window as any).bmfsApplyLang?.();
      result.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch {
      fail('Something went wrong on our side. Try again in a moment.');
    } finally {
      submit.disabled = false;
    }
  }

  submit.addEventListener('click', run);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') run();
  });

  // Paste and go — the whole interaction on a phone is one tap.
  input.addEventListener('paste', () => {
    setTimeout(() => {
      if (platformForUrl(input.value.trim())) run();
    }, 30);
  });
}
