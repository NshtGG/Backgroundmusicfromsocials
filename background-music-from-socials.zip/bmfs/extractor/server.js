/**
 * Audio extractor.
 *
 * The Astro site runs on Cloudflare Workers, which cannot spawn processes.
 * This little service does the one thing Workers can't: open a social link,
 * pull a few seconds of audio out of it, and hand back an mp3 sample.
 *
 * It never stores anything. The temp file is deleted in a finally block.
 */
import express from 'express';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const run = promisify(execFile);
const app = express();
app.use(express.json({ limit: '16kb' }));

const TOKEN = process.env.EXTRACTOR_TOKEN || '';
const ALLOWED = [
  'instagram.com', 'instagr.am',
  'youtube.com', 'youtu.be',
  'tiktok.com',
  'facebook.com', 'fb.watch',
];

function allowed(raw) {
  try {
    const host = new URL(raw).hostname.toLowerCase().replace(/^www\./, '');
    return ALLOWED.some((h) => host === h || host.endsWith('.' + h));
  } catch {
    return false;
  }
}

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/extract', async (req, res) => {
  if (TOKEN && req.get('authorization') !== `Bearer ${TOKEN}`) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  const { url, seconds = 12 } = req.body ?? {};
  if (typeof url !== 'string' || !allowed(url)) {
    return res.status(400).json({ error: 'unsupported_url' });
  }

  const dir = await mkdtemp(join(tmpdir(), 'bmfs-'));
  const out = join(dir, 'sample.mp3');

  try {
    // Skip the first second — creators often start on a hard cut or a voice.
    await run(
      'yt-dlp',
      [
        '--no-playlist',
        '--no-warnings',
        '--quiet',
        '--socket-timeout', '20',
        '-f', 'bestaudio/best',
        '-x', '--audio-format', 'mp3',
        '--postprocessor-args', `ffmpeg:-ss 1 -t ${Number(seconds) || 12} -ac 1 -ar 44100 -b:a 128k`,
        '-o', out,
        url,
      ],
      { timeout: 45_000, maxBuffer: 1024 * 1024 },
    );

    const buf = await readFile(out);
    res.json({ sample: buf.toString('base64'), bytes: buf.length });
  } catch (err) {
    const detail = String(err?.stderr || err?.message || err).slice(0, 300);
    res.status(502).json({ error: 'extract_failed', detail });
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`extractor listening on ${port}`));
