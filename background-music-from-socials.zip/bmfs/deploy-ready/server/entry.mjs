globalThis.process ??= {};
globalThis.process.env ??= {};
import { c as App, i as deserializeManifest, l as DefaultFetchHandler, o as deserializeRouteInfo } from "./chunks/entrypoints_gDNrmYwx.mjs";
import "./chunks/image-binding-transform_BvsGeQj5.mjs";
import "cloudflare:workers";
//#region \0virtual:astro-cloudflare:config
var sessionKVBindingName = "SESSION";
//#endregion
//#region \0virtual:astro:fetchable
var _virtual_astro_fetchable_default = new DefaultFetchHandler();
//#endregion
//#region \0virtual:astro:renderers
var renderers = [];
[
	{
		"file": "",
		"links": [],
		"scripts": [],
		"styles": [],
		"routeData": {
			"type": "page",
			"component": "_server-islands.astro",
			"params": ["name"],
			"segments": [[{
				"content": "_server-islands",
				"dynamic": false,
				"spread": false
			}], [{
				"content": "name",
				"dynamic": true,
				"spread": false
			}]],
			"pattern": "^\\/_server-islands\\/([^/]+?)\\/?$",
			"prerender": false,
			"isIndex": false,
			"fallbackRoutes": [],
			"route": "/_server-islands/[name]",
			"origin": "internal",
			"distURL": [],
			"_meta": { "trailingSlash": "ignore" }
		}
	},
	{
		"file": "",
		"links": [],
		"scripts": [],
		"styles": [],
		"routeData": {
			"route": "/_image",
			"component": "node_modules/@astrojs/cloudflare/dist/entrypoints/image-transform-endpoint.js",
			"params": [],
			"pathname": "/_image",
			"pattern": "^\\/_image\\/?$",
			"segments": [[{
				"content": "_image",
				"dynamic": false,
				"spread": false
			}]],
			"type": "endpoint",
			"prerender": false,
			"fallbackRoutes": [],
			"distURL": [],
			"isIndex": false,
			"origin": "internal",
			"_meta": { "trailingSlash": "ignore" }
		}
	},
	{
		"file": "",
		"links": [],
		"scripts": [],
		"styles": [],
		"routeData": {
			"route": "/api/identify",
			"isIndex": false,
			"type": "endpoint",
			"pattern": "^\\/api\\/identify\\/?$",
			"segments": [[{
				"content": "api",
				"dynamic": false,
				"spread": false
			}], [{
				"content": "identify",
				"dynamic": false,
				"spread": false
			}]],
			"params": [],
			"component": "src/pages/api/identify.ts",
			"pathname": "/api/identify",
			"prerender": false,
			"fallbackRoutes": [],
			"distURL": [],
			"origin": "project",
			"_meta": { "trailingSlash": "ignore" }
		}
	}
].map(deserializeRouteInfo);
//#endregion
//#region \0virtual:astro:pages
var _page0 = () => import("./chunks/image-transform-endpoint_ByrmdWAm.mjs");
var _page1 = () => import("./chunks/identify_CMEyTmWN.mjs");
var pageMap = /* @__PURE__ */ new Map([["node_modules/@astrojs/cloudflare/dist/entrypoints/image-transform-endpoint.js", _page0], ["src/pages/api/identify.ts", _page1]]);
//#endregion
//#region \0virtual:astro:manifest
var _manifest = deserializeManifest({"rootDir":"file:///home/claude/bmfs/","cacheDir":"file:///home/claude/bmfs/node_modules/.astro/","outDir":"file:///home/claude/bmfs/dist/","srcDir":"file:///home/claude/bmfs/src/","publicDir":"file:///home/claude/bmfs/public/","buildClientDir":"file:///home/claude/bmfs/dist/client/","buildServerDir":"file:///home/claude/bmfs/dist/server/","adapterName":"@astrojs/cloudflare","assetsDir":"_astro","routes":[{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"type":"page","component":"_server-islands.astro","params":["name"],"segments":[[{"content":"_server-islands","dynamic":false,"spread":false}],[{"content":"name","dynamic":true,"spread":false}]],"pattern":"^\\/_server-islands\\/([^/]+?)\\/?$","prerender":false,"isIndex":false,"fallbackRoutes":[],"route":"/_server-islands/[name]","origin":"internal","distURL":[],"_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/_image","component":"node_modules/@astrojs/cloudflare/dist/entrypoints/image-transform-endpoint.js","params":[],"pathname":"/_image","pattern":"^\\/_image\\/?$","segments":[[{"content":"_image","dynamic":false,"spread":false}]],"type":"endpoint","prerender":false,"fallbackRoutes":[],"distURL":[],"isIndex":false,"origin":"internal","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/api/identify","isIndex":false,"type":"endpoint","pattern":"^\\/api\\/identify\\/?$","segments":[[{"content":"api","dynamic":false,"spread":false}],[{"content":"identify","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/api/identify.ts","pathname":"/api/identify","prerender":false,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/i18n/[lang].json","isIndex":false,"type":"endpoint","pattern":"^\\/i18n\\/([^/]+?)\\.json$","segments":[[{"content":"i18n","dynamic":false,"spread":false}],[{"content":"lang","dynamic":true,"spread":false},{"content":".json","dynamic":false,"spread":false}]],"params":["lang"],"component":"src/pages/i18n/[lang].json.ts","prerender":true,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/privacy","isIndex":false,"type":"page","pattern":"^\\/privacy\\/?$","segments":[[{"content":"privacy","dynamic":false,"spread":false}]],"params":[],"component":"src/pages/privacy.astro","pathname":"/privacy","prerender":true,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/[platform]","isIndex":false,"type":"page","pattern":"^\\/([^/]+?)\\/?$","segments":[[{"content":"platform","dynamic":true,"spread":false}]],"params":["platform"],"component":"src/pages/[platform].astro","prerender":true,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}},{"file":"","links":[],"scripts":[],"styles":[],"routeData":{"route":"/","isIndex":true,"type":"page","pattern":"^\\/$","segments":[],"params":[],"component":"src/pages/index.astro","pathname":"/","prerender":true,"fallbackRoutes":[],"distURL":[],"origin":"project","_meta":{"trailingSlash":"ignore"}}}],"serverLike":true,"middlewareMode":"classic","site":"https://backgroundmusicfromsocials.com","base":"/","trailingSlash":"ignore","compressHTML":"jsx","componentMetadata":[["/home/claude/bmfs/src/pages/[platform].astro",{"propagation":"none","containsHead":true}],["/home/claude/bmfs/src/pages/index.astro",{"propagation":"none","containsHead":true}],["/home/claude/bmfs/src/pages/privacy.astro",{"propagation":"none","containsHead":true}]],"renderers":[],"clientDirectives":[["idle","(()=>{var l=(n,t)=>{let i=async()=>{await(await n())()},e=typeof t.value==\"object\"?t.value:void 0,s={timeout:e==null?void 0:e.timeout};\"requestIdleCallback\"in window?window.requestIdleCallback(i,s):setTimeout(i,s.timeout||200)};(self.Astro||(self.Astro={})).idle=l;window.dispatchEvent(new Event(\"astro:idle\"));})();"],["load","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).load=e;window.dispatchEvent(new Event(\"astro:load\"));})();"],["media","(()=>{var n=(a,t)=>{let i=async()=>{await(await a())()};if(t.value){let e=matchMedia(t.value);e.matches?i():e.addEventListener(\"change\",i,{once:!0})}};(self.Astro||(self.Astro={})).media=n;window.dispatchEvent(new Event(\"astro:media\"));})();"],["only","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).only=e;window.dispatchEvent(new Event(\"astro:only\"));})();"],["visible","(()=>{var a=(s,i,o)=>{let r=async()=>{await(await s())()},t=typeof i.value==\"object\"?i.value:void 0,c={rootMargin:t==null?void 0:t.rootMargin},n=new IntersectionObserver(e=>{for(let l of e)if(l.isIntersecting){n.disconnect(),r();break}},c);for(let e of o.children)n.observe(e)};(self.Astro||(self.Astro={})).visible=a;window.dispatchEvent(new Event(\"astro:visible\"));})();"]],"entryModules":{"virtual:cloudflare/worker-entry":"entry.mjs","\u0000virtual:astro:page:src/pages/i18n/[lang].json@_@ts":"chunks/_lang__COSlLEzY.mjs","\u0000noop-middleware":"virtual_astro_middleware.mjs","\u0000virtual:astro:page:src/pages/[platform]@_@astro":"chunks/_platform__ioambrPK.mjs","\u0000virtual:astro:server-island-manifest":"chunks/_virtual_astro_server-island-manifest_q0HM18kM.mjs","\u0000virtual:astro:session-driver":"chunks/_virtual_astro_session-driver_TyipGO2P.mjs","/home/claude/bmfs/node_modules/@astrojs/cloudflare/dist/entrypoints/image-service-workerd.js":"chunks/image-service-workerd_wle6paUB.mjs","\u0000virtual:astro:page:src/pages/index@_@astro":"chunks/index_raSmmoIU.mjs","\u0000virtual:astro:actions/noop-entrypoint":"chunks/noop-entrypoint_BYLrzUxc.mjs","\u0000virtual:astro:page:src/pages/privacy@_@astro":"chunks/privacy_PmwHatD_.mjs","/home/claude/bmfs/node_modules/@astrojs/cloudflare/dist/utils/static-image-collection.js":"chunks/static-image-collection_D0V4SlLw.mjs","\u0000virtual:astro:page:src/pages/api/identify@_@ts":"chunks/identify_CMEyTmWN.mjs","\u0000virtual:astro:page:node_modules/@astrojs/cloudflare/dist/entrypoints/image-transform-endpoint@_@js":"chunks/image-transform-endpoint_ByrmdWAm.mjs","/home/claude/bmfs/src/layouts/Base.astro?astro&type=script&index=0&lang.ts":"_astro/Base.astro_astro_type_script_index_0_lang.DlC2rzmn.js","/home/claude/bmfs/src/components/Finder.astro?astro&type=script&index=0&lang.ts":"_astro/Finder.astro_astro_type_script_index_0_lang.CBlupUvv.js","astro:scripts/before-hydration.js":""},"inlinedScripts":[["/home/claude/bmfs/src/layouts/Base.astro?astro&type=script&index=0&lang.ts","globalThis.process??={},globalThis.process.env??={};var e=document.documentElement;document.getElementById(`theme-btn`)?.addEventListener(`click`,()=>{let t=e.dataset.theme===`dark`?`light`:`dark`;e.dataset.theme=t;try{localStorage.setItem(`bmfs-theme`,t)}catch{}});var t=document.getElementById(`lang-btn`),n=document.getElementById(`lang-panel`),r=document.getElementById(`lang-current`);function i(){!n||!t||(n.hidden=!0,t.setAttribute(`aria-expanded`,`false`))}t?.addEventListener(`click`,e=>{if(e.stopPropagation(),!n)return;let r=n.hidden;n.hidden=!r,t.setAttribute(`aria-expanded`,String(r)),r&&n.querySelector(`[aria-selected=\"true\"]`)?.scrollIntoView({block:`center`})}),document.addEventListener(`click`,e=>{!n||n.hidden||e.target.closest(`#lang-menu`)||i()}),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&i()});async function a(t){let i=null;try{let e=sessionStorage.getItem(`bmfs-dict-`+t);i=e?JSON.parse(e):null}catch{}if(!i)try{let e=await fetch(`/i18n/${t}.json`);if(!e.ok)return;i=await e.json();try{sessionStorage.setItem(`bmfs-dict-`+t,JSON.stringify(i))}catch{}}catch{return}if(i){e.lang=t===`zt`?`zh-Hant`:t===`zh`?`zh-Hans`:t,e.dir=i.__dir===`rtl`?`rtl`:`ltr`,document.querySelectorAll(`[data-i18n]`).forEach(e=>{let t=i[e.dataset.i18n];if(t===void 0)return;let n=e.dataset.i18nP;n&&(t=t.replaceAll(`{p}`,n)),e.textContent=t}),document.querySelectorAll(`[data-i18n-placeholder]`).forEach(e=>{let t=i[e.dataset.i18nPlaceholder];t!==void 0&&(e.placeholder=t)}),document.querySelectorAll(`[data-i18n-label]`).forEach(e=>{let t=i[e.dataset.i18nLabel];t!==void 0&&e.setAttribute(`aria-label`,t)}),window.__bmfsDict=i,n?.querySelectorAll(`[data-lang]`).forEach(e=>{let n=e.dataset.lang===t;e.setAttribute(`aria-selected`,String(n)),n&&r&&(r.textContent=e.textContent?.trim()??t)});try{localStorage.setItem(`bmfs-lang`,t)}catch{}}}n?.querySelectorAll(`[data-lang]`).forEach(e=>{e.addEventListener(`click`,()=>{a(e.dataset.lang),i()})});var o=null;try{o=localStorage.getItem(`bmfs-lang`)}catch{}o&&a(o),window.bmfsApplyLang=()=>{let e=n?.querySelector(`[aria-selected=\"true\"]`)?.dataset.lang;e&&e!==`en`&&a(e)};"],["/home/claude/bmfs/src/components/Finder.astro?astro&type=script&index=0&lang.ts","globalThis.process??={},globalThis.process.env??={};var e=[{slug:`instagram`,name:`Instagram`,hosts:[`instagram.com`,`instagr.am`],hint:`Reels, posts and stories. Open the reel, tap Share, then Copy link.`},{slug:`youtube`,name:`YouTube`,hosts:[`youtube.com`,`youtu.be`],hint:`Full videos and Shorts. Paste the address straight from the bar.`},{slug:`tiktok`,name:`TikTok`,hosts:[`tiktok.com`],hint:`Tap Share, then Copy link. Short vm.tiktok.com links work too.`},{slug:`facebook`,name:`Facebook`,hosts:[`facebook.com`,`fb.watch`],hint:`Reels and video posts. Use the link from the post menu.`}];function t(t){try{let n=new URL(t.trim()).hostname.toLowerCase().replace(/^www\\./,``);return e.find(e=>e.hosts.some(e=>n===e||n.endsWith(`.`+e)))??null}catch{return null}}var n=(e,t)=>e.querySelector(`[data-role=\"${t}\"]`);function r(e,t){return window.__bmfsDict?.[e]??t}function i(i){let a=n(i,`input`),o=n(i,`submit`),s=n(i,`loading`),c=n(i,`result`),l=n(i,`error`),u=i.dataset.platform||null,d=e=>e&&(e.hidden=!1),f=e=>e&&(e.hidden=!0);function p(e){f(s),f(c),l.textContent=e,d(l),o.disabled=!1}async function m(){let m=a.value.trim();if(f(l),f(c),!m){a.focus();return}let h=t(m);if(!h){p(r(`errBadLink`,`That link is not supported.`));return}if(u&&h.slug!==u){let t=e.find(e=>e.slug===h.slug);p(`That is a ${t.name} link. Use the ${t.name} tool at /${t.slug}.`);return}o.disabled=!0,d(s);try{let e=await fetch(`/api/identify`,{method:`POST`,headers:{\"content-type\":`application/json`},body:JSON.stringify({url:m})}),t=await e.json();if(!e.ok||!t.ok){p(t.message||r(`errNoMatch`,`No match. Try a clip where the music is clearer.`));return}n(i,`title`).textContent=t.track.title,n(i,`artist`).textContent=t.track.artist;let a=[t.track.album,t.track.year,t.track.label].filter(Boolean);n(i,`meta`).textContent=a.join(` · `);let o=`https://www.youtube.com/results?search_query=${encodeURIComponent(`${t.track.artist} ${t.track.title}`)}`,l=n(i,`player-wrap`),u=n(i,`player`),h=n(i,`listen`);t.track.youtubeId?(u.src=`https://www.youtube-nocookie.com/embed/${t.track.youtubeId}?rel=0&playsinline=1`,l.hidden=!1,h.href=`https://www.youtube.com/watch?v=${t.track.youtubeId}`):(u.removeAttribute(`src`),l.hidden=!0,h.href=o),f(s),d(c),window.bmfsApplyLang?.(),c.scrollIntoView({behavior:`smooth`,block:`nearest`})}catch{p(`Something went wrong on our side. Try again in a moment.`)}finally{o.disabled=!1}}o.addEventListener(`click`,m),a.addEventListener(`keydown`,e=>{e.key===`Enter`&&m()}),a.addEventListener(`paste`,()=>{setTimeout(()=>{t(a.value.trim())&&m()},30)})}document.querySelectorAll(`.finder`).forEach(i);"]],"assets":["/favicon.svg","/robots.txt","/_astro/Base.Cz0hOFHW.css","/_astro/montserrat-cyrillic-ext-400-normal.Xqov12YL.woff2","/_astro/montserrat-cyrillic-ext-400-normal.DRPPeomZ.woff","/_astro/montserrat-cyrillic-400-normal.BPq32Q8K.woff2","/_astro/montserrat-cyrillic-400-normal.jEs4Tk-Z.woff","/_astro/montserrat-vietnamese-400-normal.D4oHqQTd.woff2","/_astro/montserrat-vietnamese-400-normal.BeEscFYY.woff","/_astro/montserrat-latin-ext-400-normal.B8bwfy6Y.woff2","/_astro/montserrat-latin-ext-400-normal.BffdBkAA.woff","/_astro/montserrat-latin-400-normal.BLhwKU8k.woff2","/_astro/montserrat-latin-400-normal.xItZbAXg.woff","/_astro/montserrat-cyrillic-ext-500-normal.11xBT7e1.woff2","/_astro/montserrat-cyrillic-ext-500-normal.DOzfAZ45.woff","/_astro/montserrat-cyrillic-500-normal.T0SG181k.woff2","/_astro/montserrat-cyrillic-500-normal.CyGtXmN9.woff","/_astro/montserrat-vietnamese-500-normal.NT-t8RG1.woff2","/_astro/montserrat-vietnamese-500-normal.DpeZlV_K.woff","/_astro/montserrat-latin-ext-500-normal.BKtbrd6n.woff2","/_astro/montserrat-latin-ext-500-normal.DWPqqZgs.woff","/_astro/montserrat-latin-500-normal.DRFEGfly.woff2","/_astro/montserrat-latin-500-normal.Dok2oTci.woff","/_astro/montserrat-cyrillic-ext-600-normal.BtBW-rpm.woff2","/_astro/montserrat-cyrillic-ext-600-normal.wReYPmz2.woff","/_astro/montserrat-cyrillic-600-normal.CQEPC0hM.woff2","/_astro/montserrat-cyrillic-600-normal.DUglwBrH.woff","/_astro/montserrat-vietnamese-600-normal.DKe6qT_E.woff2","/_astro/montserrat-vietnamese-600-normal.SJ-HTWuM.woff","/_astro/montserrat-latin-ext-600-normal.DSkTqI9L.woff2","/_astro/montserrat-latin-ext-600-normal.CSDhkhgS.woff","/_astro/montserrat-latin-600-normal.UVxSCcoG.woff2","/_astro/montserrat-latin-600-normal.CdhFl4lI.woff","/_astro/montserrat-cyrillic-ext-700-normal.MyDreaeu.woff2","/_astro/montserrat-cyrillic-ext-700-normal.D-Mk2xRJ.woff","/_astro/montserrat-cyrillic-700-normal.D-Pqjtdp.woff2","/_astro/montserrat-cyrillic-700-normal.BvLYcGP1.woff","/_astro/montserrat-vietnamese-700-normal.C0x1De3p.woff2","/_astro/montserrat-vietnamese-700-normal.DnwGT2D9.woff","/_astro/montserrat-latin-ext-700-normal.BOP2Nhf0.woff2","/_astro/montserrat-latin-ext-700-normal.DdDFr05Z.woff","/_astro/montserrat-latin-700-normal.BdjcYUrC.woff2","/_astro/montserrat-latin-700-normal.BWkrl476.woff","/privacy/index.html","/index.html"],"buildFormat":"directory","checkOrigin":true,"actionBodySizeLimit":1048576,"serverIslandBodySizeLimit":1048576,"allowedDomains":[],"key":"yjkMxvE/wtCnPKZWnbSpOCQ0Ke403GVxl5nL7KU1r3U=","sessionConfig":{"driver":"unstorage/drivers/cloudflare-kv-binding","options":{"binding":"SESSION"}},"image":{},"devToolbar":{"enabled":false,"debugInfoOutput":""},"logLevel":"info","shouldInjectCspMetaTags":false});
var manifestRoutes = _manifest.routes;
var manifest = Object.assign(_manifest, {
	renderers,
	actions: () => import("./chunks/noop-entrypoint_BYLrzUxc.mjs"),
	middleware: () => import("./virtual_astro_middleware.mjs"),
	sessionDriver: () => import("./chunks/_virtual_astro_session-driver_TyipGO2P.mjs"),
	serverIslandMappings: () => import("./chunks/_virtual_astro_server-island-manifest_q0HM18kM.mjs"),
	routes: manifestRoutes,
	pageMap
});
//#endregion
//#region node_modules/astro/dist/core/app/entrypoints/virtual/prod.js
var createApp$1 = ({ streaming } = {}) => {
	const app = new App(manifest, streaming);
	app.setFetchHandler(_virtual_astro_fetchable_default);
	return app;
};
//#endregion
//#region node_modules/astro/dist/core/app/entrypoints/virtual/index.js
var createApp = createApp$1;
//#endregion
//#region node_modules/@astrojs/internal-helpers/dist/request.js
function getFirstForwardedValue(multiValueHeader) {
	return multiValueHeader?.toString()?.split(",").map((e) => e.trim())?.[0];
}
var IP_RE = /^[0-9a-fA-F.:]{1,45}$/;
function isValidIpAddress(value) {
	return IP_RE.test(value);
}
function getValidatedIpFromHeader(headerValue) {
	const raw = getFirstForwardedValue(headerValue);
	if (raw && isValidIpAddress(raw)) return raw;
}
//#endregion
//#region node_modules/@astrojs/cloudflare/dist/utils/cf-helpers.js
function matchStaticAsset(manifest, requestUrl, env) {
	const { pathname } = new URL(requestUrl);
	if (manifest.assets.has(pathname)) return env.ASSETS.fetch(requestUrl.replace(/\.html$/, ""));
}
async function fallbackToAssets(requestUrl, env) {
	const asset = await env.ASSETS.fetch(requestUrl.replace(/index.html$/, "").replace(/\.html$/, ""));
	if (asset.status !== 404) return asset;
}
function createErrorPageFetch(env) {
	return async (url) => {
		return env.ASSETS.fetch(url.replace(/\.html$/, ""));
	};
}
function createLocals(ctx) {
	const locals = { cfContext: ctx };
	Object.defineProperty(locals, "runtime", {
		enumerable: false,
		value: {
			get env() {
				throw new Error(`Astro.locals.runtime.env has been removed in Astro v6. Use 'import { env } from "cloudflare:workers"' instead.`);
			},
			get cf() {
				throw new Error(`Astro.locals.runtime.cf has been removed in Astro v6. Use 'Astro.request.cf' instead.`);
			},
			get caches() {
				throw new Error(`Astro.locals.runtime.caches has been removed in Astro v6. Use the global 'caches' object instead.`);
			},
			get ctx() {
				throw new Error(`Astro.locals.runtime.ctx has been removed in Astro v6. Use 'Astro.locals.cfContext' instead.`);
			}
		}
	});
	return locals;
}
function getClientAddress(request) {
	return getValidatedIpFromHeader(request.headers.get("cf-connecting-ip"));
}
//#endregion
//#region node_modules/@astrojs/cloudflare/dist/utils/cf.js
function injectSessionBinding(manifest, env) {
	if (env["SESSION"]) {
		const sessionConfigOptions = manifest.sessionConfig?.options ?? {};
		Object.assign(sessionConfigOptions, { binding: env[sessionKVBindingName] });
	}
}
var app = createApp();
async function handle(request, env, context) {
	injectSessionBinding(app.manifest, env);
	const staticAsset = matchStaticAsset(app.manifest, request.url, env);
	if (staticAsset) return staticAsset;
	let routeData = void 0;
	if (app.isDev()) {
		const result = await app.devMatch(app.getPathnameFromRequest(request));
		if (result) routeData = result.routeData;
	} else routeData = app.match(request);
	if (!routeData) {
		const asset = await fallbackToAssets(request.url, env);
		if (asset) return asset;
	}
	const locals = createLocals(context);
	const waitUntil = context.waitUntil.bind(context);
	let response = await app.render(request, {
		routeData,
		locals,
		waitUntil,
		prerenderedErrorPageFetch: createErrorPageFetch(env),
		clientAddress: getClientAddress(request)
	});
	const setCookieHeaders = app.setCookieHeaders ? [...app.setCookieHeaders(response)] : [];
	if (setCookieHeaders.length > 0 || false) {
		const applyHeaders = (res) => {
			for (const setCookieHeader of setCookieHeaders) res.headers.append("Set-Cookie", setCookieHeader);
		};
		try {
			applyHeaders(response);
		} catch {
			response = new Response(response.body, response);
			applyHeaders(response);
		}
	}
	return response;
}
//#endregion
//#region \0virtual:cloudflare/worker-entry
var worker_entry_default = { fetch: handle };
//#endregion
export { worker_entry_default as default };
