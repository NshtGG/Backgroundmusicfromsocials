import { defineConfig } from 'astro/config';
import cloudflare from '@astrojs/cloudflare';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  site: 'https://backgroundmusicfromsocials.com',
  adapter: cloudflare(),
  vite: { plugins: [tailwindcss()] },
});
